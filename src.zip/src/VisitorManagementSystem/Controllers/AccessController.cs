﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Threading.Tasks;
using System.Security.Claims;
using VisitorManagementSystem.Models;

namespace VisitorManagementSystem.Controllers
{
    public class AccessController : Controller
    {
        // GET: /Access/Login
        public IActionResult Login()
        {
            // Check if there was a login failure and set ViewData accordingly
            ViewData["ShowErrorPopup"] = TempData["ShowErrorPopup"];

            // Check if the user is already authenticated
            if (User.Identity.IsAuthenticated)
            {
                // If user is already authenticated, redirect to the home page
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        // POST: /Access/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(VMLogin modelLogin)
        {
            // Validate model state
            if (!ModelState.IsValid)
            {
                return View(modelLogin);
            }

            // Example: Hardcoded credentials (replace with your actual authentication logic)
            if (modelLogin.Username == "sanjay" && modelLogin.Password == "bhel")
            {
                // Create claims for the authenticated user
                var claims = new[]
                {
                    new Claim(ClaimTypes.Name, modelLogin.Username),
                    // Add more claims as needed
                };

                // Create identity
                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                // Create principal
                var principal = new ClaimsPrincipal(identity);

                // Sign in the user
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                // Redirect to a protected resource or a specific URL
                return RedirectToAction("Index", "Home");
            }
            else
            {
                // If the credentials are invalid, redisplay the login form with an error message
                TempData["ShowErrorPopup"] = true; // Set TempData to indicate login failure
                ModelState.AddModelError(string.Empty, "Invalid username or password");
                return View(modelLogin);
            }
        }

        // POST: /Access/Logout
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            // Sign out the user
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate"; // HTTP 1.1
            Response.Headers["Pragma"] = "no-cache"; // HTTP 1.0
            Response.Headers["Expires"] = "0"; // Proxies

            // Redirect to the login page after logout
            return RedirectToAction("Login", "Access");
        }


    }




}
