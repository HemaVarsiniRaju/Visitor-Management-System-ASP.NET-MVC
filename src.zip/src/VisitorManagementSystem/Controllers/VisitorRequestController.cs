﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VisitorManagementSystem.Data;
using VisitorManagementSystem.Models;
using VisitorManagementSystem.Models.Entites;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace VisitorManagementSystem.Controllers
{
    public class VisitorRequestController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public VisitorRequestController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult RequestVisitor()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RequestVisitor(VisitorPassRequestModelView viewModel)
        {
            var visitorRequest = new VisitorRequest
            {
                VisitorName = viewModel.VisitorName,
                VisitPurpose = viewModel.VisitPurpose,
                Date = viewModel.Date,
                VisitorAddress = viewModel.VisitorAddress,
                ToBeVisited = viewModel.ToBeVisited,
                AllowedItems = viewModel.AllowedItems,
                DepartmentToBeVisited = viewModel.DepartmentToBeVisited,
                Designation = viewModel.Designation,
                Status = "Pending"
            };

            await dbContext.visitorRequests.AddAsync(visitorRequest);
            await dbContext.SaveChangesAsync();

            TempData["Message"] = "GatePass Request Sent successfully.";

            // Redirect to VisitorRequestList after submitting request
            return RedirectToAction("VisitorRequestList");
        }

        [HttpGet]
        public async Task<IActionResult> VisitorRequestList()
        {
            var visitorPendingRequests = await dbContext.visitorRequests
                .Where(x => x.Status == "Pending")
                .ToListAsync();
            return View(visitorPendingRequests);
        }

        [HttpGet]
        public async Task<IActionResult> ApprovedList()
        {
            var approvedRequests = await dbContext.visitorRequests
                .Where(x => x.Status == "Approved")
                .ToListAsync();
            return View(approvedRequests);
        }

        [HttpGet]
        public async Task<IActionResult> AllGatePassList()
        {
            var allGatePasses = await dbContext.visitorRequests.ToListAsync();
            return View(allGatePasses);
        }

        [HttpPost]
        public ActionResult Approve(Guid id)
        {
            var requestToApprove = dbContext.visitorRequests.Find(id);
            if (requestToApprove != null)
            {
                requestToApprove.Status = "Approved";
                dbContext.SaveChanges();
                TempData["Message"] = "GatePass approved successfully.";
            }
            // Redirect to AllGatePassList after approval
            return RedirectToAction("AllGatePassList");
        }

        [HttpPost]
        public ActionResult Reject(Guid id)
        {
            var requestToReject = dbContext.visitorRequests.Find(id);
            if (requestToReject != null)
            {
                requestToReject.Status = "Rejected";
                dbContext.SaveChanges();
                TempData["Message"] = "GatePass rejected successfully.";
            }
            // Redirect to AllGatePassList after rejection
            return RedirectToAction("AllGatePassList");
        }
    }
}