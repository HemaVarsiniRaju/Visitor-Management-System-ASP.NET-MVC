﻿namespace VisitorManagementSystem.Models
{
    public class VisitorPassRequestModelView
    {
        public Guid Id { get; set; }
        public String VisitPurpose { get; set; }

        public DateTime Date { get; set; }

        public String ToBeVisited { get; set; }

        public String VisitorName { get; set; }
        public String AllowedItems { get; set; }


        public String DepartmentToBeVisited { get; set; }
        public String Designation { get; set; }
        public String VisitorAddress { get; set; }
        public string Status { get; set; }
    }
}
