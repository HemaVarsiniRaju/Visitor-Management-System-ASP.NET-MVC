﻿namespace VisitorManagementSystem.Models
{
    public class VMLogin
    {
            public string Username { get; set; }
            public string Password { get; set; }
    }
}
